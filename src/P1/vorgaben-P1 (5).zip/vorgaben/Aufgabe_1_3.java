public class Aufgabe_1_3 {

    public static void main(String[] args){
	System.out.println("Bitte geben Sie folgende Daten ein:");


    }
}
