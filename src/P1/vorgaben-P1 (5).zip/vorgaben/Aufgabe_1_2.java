public class Aufgabe_1_2 {
    public static void main(String[] args){	
	int a = 1, b = 2, c = 3, d = 4;
	
	
	/*  Aufgabenteil (a) 
	    
	 */

	// a + b * c - d / b;
	System.out.println(); 

	a = 1; b = 2; c = 3; d = 4; // reinitialisieren


	/* Aufgabenteil (b) 
	    
	 */ 
	// a + a++ + ++a + a;
	System.out.println(); 

	a = 1; b = 2; c = 3; d = 4; // reinitialisieren


	/* Aufgabenteil (c) 

	 */ 

	// a -= b += ++c;
	System.out.println(); 

	a = 1; b = 2; c = 3; d = 4;  // reinitialisieren

	/*  Aufgabenteil (d) 

	 */ 

	// a * d < b * c || a + d != b + c;
	System.out.println(); 

	a = 1; b = 2; c = 3; d = 4;      //  reinitialisieren

	/* Aufgabenteil (e) 
	  
	 */
	// !(-1 * a + b < d - c) ? ++a * ++a : c++ + ++c;
	System.out.println(); 

	a = 1; b = 2; c = 3; d = 4;   //  reinitialisieren

 	/* Aufgabenteil (f) 

	 */
	int h1, h2;
	// (h1 = ((a > b) ? b : a)) > (h2 = ((c > d) ? d : c)) ? h2 : h1;
	System.out.println(); 
   }
}

