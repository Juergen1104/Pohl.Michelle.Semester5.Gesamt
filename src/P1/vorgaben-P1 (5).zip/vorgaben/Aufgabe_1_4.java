public class Aufgabe_1_4 {
    public static void main(String[] args){
	
   }
}
