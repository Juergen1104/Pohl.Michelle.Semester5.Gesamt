public class Aufgabe_1_1 {
    public static void main(String[] args){
	// char c = "'";
        // char d = '"'; 
        // double d1 = .1f1;
        // double d2 = 12.5F-12;
        // int i = 1E2;
        // int j = 0b11;
        // long k = OxFEDCBA;
        // long l = 1l;
        // int x = (0x1 < 0x2); 
        // float f = (-1 > 0) ? 1.5 * 2 : 1.5 % 2;
   }
}
